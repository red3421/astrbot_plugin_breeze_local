"""音频缓存：同样的请求参数直接复用磁盘上的 wav，省得重复推理。"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path


class AudioCache:
    def __init__(self, root: Path, expire_hours: float = 30.0, enabled: bool = True) -> None:
        self.root = Path(root)
        self.expire_hours = float(expire_hours)
        self.enabled = bool(enabled)
        if self.enabled:
            self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def make_key(voice_id: str, text: str, instruction: str, cfg_scale: float, seed: int) -> str:
        raw = json.dumps(
            {
                "v": voice_id,
                "t": text,
                "i": instruction,
                "c": round(float(cfg_scale), 3),
                "s": int(seed),
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

    def _path(self, key: str) -> Path:
        return self.root / f"{key}.wav"

    def get(self, key: str) -> bytes | None:
        if not self.enabled:
            return None
        path = self._path(key)
        if not path.is_file():
            return None
        # expire_hours <= 0 表示永不过期
        if self.expire_hours > 0:
            age_h = (time.time() - path.stat().st_mtime) / 3600.0
            if age_h > self.expire_hours:
                try:
                    path.unlink()
                except OSError:
                    pass
                return None
        try:
            data = path.read_bytes()
        except OSError:
            return None
        return data or None

    def put(self, key: str, data: bytes) -> None:
        if not self.enabled or not data:
            return
        path = self._path(key)
        tmp = path.with_suffix(".tmp")
        try:
            tmp.write_bytes(data)
            tmp.replace(path)  # 原子替换，写一半崩了也不会坏掉旧文件
        except OSError:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass

    def stats(self) -> dict[str, int]:
        if not self.enabled or not self.root.is_dir():
            return {"files": 0, "bytes": 0}
        files = list(self.root.glob("*.wav"))
        return {"files": len(files), "bytes": sum(f.stat().st_size for f in files)}

    def clear(self) -> int:
        if not self.enabled or not self.root.is_dir():
            return 0
        count = 0
        for f in self.root.glob("*.wav"):
            try:
                f.unlink()
                count += 1
            except OSError:
                pass
        return count

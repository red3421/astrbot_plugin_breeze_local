const bridge = window.AstrBotPluginView;

const els = {
  search: document.getElementById("search"),
  refresh: document.getElementById("refresh"),
  status: document.getElementById("status"),
  list: document.getElementById("list"),
  current: document.getElementById("current"),
  subtitle: document.getElementById("subtitle"),
  cacheinfo: document.getElementById("cacheinfo"),
  clearcache: document.getElementById("clearcache"),
};

const state = {
  voices: [],
  selected: "",
  loading: false,
};

function setStatus(message, isError = false) {
  els.status.textContent = message;
  els.status.classList.toggle("error", isError);
}

function setLoading(loading) {
  state.loading = loading;
  els.refresh.disabled = loading;
  els.refresh.textContent = loading ? "读取中…" : "刷新";
}

function match(voice, kw) {
  if (!kw) return true;
  const hay = [
    voice.voice_id,
    voice.name,
    voice.description,
    voice.ref_text,
    ...Object.values(voice.metadata || {}),
  ]
    .join(" ")
    .toLowerCase();
  return hay.includes(kw.toLowerCase());
}

function render() {
  els.list.replaceChildren();
  const kw = els.search.value.trim();
  const shown = state.voices.filter((v) => match(v, kw));

  if (!shown.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = state.voices.length
      ? "没有匹配的音色，换个关键词试试。"
      : "服务端音色库是空的。去本机的语音库页面存几个声音吧。";
    els.list.append(p);
    return;
  }

  for (const voice of shown) {
    const isSelected = voice.voice_id === state.selected;
    const card = document.createElement("article");
    card.className = "voice" + (isSelected ? " selected" : "");

    const info = document.createElement("div");
    info.className = "voice-info";

    const title = document.createElement("div");
    title.className = "title";
    const name = document.createElement("strong");
    name.textContent = voice.name || voice.voice_id;
    title.append(name);
    if (isSelected) {
      const badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = "当前默认";
      title.append(badge);
    }
    const secs = document.createElement("span");
    secs.className = "badge";
    secs.textContent = `${voice.seconds}s`;
    title.append(secs);

    const id = document.createElement("code");
    id.textContent = voice.voice_id;

    const ref = document.createElement("span");
    ref.className = "meta";
    ref.textContent = voice.ref_text || "（无参考文本）";

    info.append(title, id, ref);

    const btn = document.createElement("button");
    btn.textContent = isSelected ? "当前默认" : "设为默认";
    btn.disabled = isSelected;
    if (!isSelected) btn.className = "primary";
    btn.addEventListener("click", () => selectVoice(voice.voice_id));

    card.append(info, btn);
    els.list.append(card);
  }
}

function renderCache(cache) {
  if (!cache) {
    els.cacheinfo.textContent = "缓存信息不可用";
    return;
  }
  if (!cache.enabled) {
    els.cacheinfo.textContent = "缓存：已关闭";
    els.clearcache.disabled = true;
    return;
  }
  const expire = cache.expire_hours > 0 ? `${cache.expire_hours} 小时` : "永不过期";
  els.cacheinfo.textContent =
    `缓存：${cache.files} 个文件 / ${cache.mb} MB ｜ 命中 ${cache.hits} 次 ｜ 过期 ${expire}`;
}

async function loadVoices() {
  if (!bridge) {
    setStatus("没检测到 AstrBot 插件页桥接，请从 AstrBot 的插件详情页打开。", true);
    return;
  }
  if (state.loading) return;

  setLoading(true);
  setStatus("正在拉取音色库…");
  try {
    const data = await bridge.apiGet("voices");
    state.voices = Array.isArray(data.voices) ? data.voices : [];
    state.selected = data.selected_voice_id || "";
    els.current.textContent = state.selected || "未设置";
    els.subtitle.textContent = `服务地址 ${data.api_base}，共 ${data.total} 个音色。`;
    renderCache(data.cache);
    setStatus(`已获取 ${data.total} 个音色。`);
  } catch (err) {
    setStatus(`拉取失败：${err.message || err}`, true);
  } finally {
    setLoading(false);
    render();
  }
}

async function clearCache() {
  if (!bridge) return;
  els.clearcache.disabled = true;
  setStatus("正在清空缓存…");
  try {
    const data = await bridge.apiPost("cache/clear", {});
    setStatus(`已清掉 ${data.cleared ?? 0} 个缓存文件。`);
    await loadVoices();
  } catch (err) {
    setStatus(`清空失败：${err.message || err}`, true);
  } finally {
    els.clearcache.disabled = false;
  }
}

async function selectVoice(voiceId) {
  if (!bridge || !voiceId || state.loading) return;
  state.loading = true;
  setStatus(`正在保存 ${voiceId}…`);
  try {
    const result = await bridge.apiPost("select", { voice_id: voiceId });
    state.selected = result.voice_id || voiceId;
    els.current.textContent = state.selected;
    setStatus(`已把 ${state.selected} 设为默认音色。`);
  } catch (err) {
    setStatus(`保存失败：${err.message || err}`, true);
  } finally {
    state.loading = false;
    render();
  }
}

els.refresh.addEventListener("click", loadVoices);
els.clearcache.addEventListener("click", clearCache);
els.search.addEventListener("input", render);
els.search.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    e.preventDefault();
    loadVoices();
  }
});

async function init() {
  if (!bridge) {
    setStatus("没检测到 AstrBot 插件页桥接，请从 AstrBot 的插件详情页打开。", true);
    return;
  }
  await bridge.ready();
  await loadVoices();
}

init();

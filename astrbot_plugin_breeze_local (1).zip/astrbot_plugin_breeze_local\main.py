"""AstrBot 插件：把本机 Breeze-TTS-2.cpp 服务接入 AstrBot。

做四件事：
1. 拉取服务端的音色库（GET /v1/voices）
2. 用选中的音色合成语音（POST /v1/audio/speech）
3. 提供一个插件页让用户挑音色
4. 可选地把 LLM 回复主动转成语音，带情感判断与音频缓存
"""

from __future__ import annotations

import asyncio
import io
import random
import re
import time
import wave
from pathlib import Path
from typing import Any

import aiohttp

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import Record
from astrbot.api.star import Context, Star
from astrbot.core.config.astrbot_config import AstrBotConfig

try:  # 作为包导入
    from .cache import AudioCache
except ImportError:  # AstrBot 以顶层模块方式加载
    from cache import AudioCache

PLUGIN_NAME = "astrbot_plugin_breeze_local"

DEFAULT_BASE = "http://127.0.0.1:8080"

# 去掉 markdown / 表情包 / 链接，留下能念的正文
_CLEAN_PATTERNS = [
    (re.compile(r"```.*?```", re.S), ""),
    (re.compile(r"`([^`]*)`"), r"\1"),
    (re.compile(r"!\[[^\]]*\]\([^)]*\)"), ""),
    (re.compile(r"\[([^\]]*)\]\([^)]*\)"), r"\1"),
    (re.compile(r"https?://\S+"), ""),
    (re.compile(r"[*_~#>|]"), ""),
    (re.compile(r"^\s*[-+]\s+", re.M), ""),
]


class BreezeError(Exception):
    """服务端返回错误或连接失败。"""


def pcm_to_wav(pcm: bytes, sample_rate: int = 24000) -> bytes:
    """服务端返回的是裸 16-bit 单声道 PCM，套个 WAV 头才能播。"""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm)
    return buf.getvalue()


def clean_text(text: str) -> str:
    """把 LLM 输出里的 markdown 之类的噪音去掉，留下能念的话。"""
    out = text or ""
    for pattern, repl in _CLEAN_PATTERNS:
        out = pattern.sub(repl, out)
    return re.sub(r"\n{2,}", "\n", out).strip()


class BreezeClient:
    """跟本机 breeze-server 说话的最小封装。"""

    def __init__(self, base: str, timeout: float) -> None:
        self.base = base.rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=self.timeout)
        return self._session

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
        self._session = None

    async def health(self) -> dict[str, Any]:
        session = await self._get_session()
        try:
            async with session.get(f"{self.base}/health") as resp:
                if resp.status != 200:
                    raise BreezeError(f"服务不可达（HTTP {resp.status}）")
                return await resp.json(content_type=None)
        except aiohttp.ClientError as exc:
            raise BreezeError(f"连不上 {self.base}：{exc}") from exc

    async def list_voices(self) -> list[dict[str, Any]]:
        """服务端返回的是裸数组，每项形如 {id, seconds, ref_text, description, ...}。"""
        session = await self._get_session()
        try:
            async with session.get(f"{self.base}/v1/voices") as resp:
                if resp.status != 200:
                    raise BreezeError(f"拉取音色库失败（HTTP {resp.status}）")
                data = await resp.json(content_type=None)
        except aiohttp.ClientError as exc:
            raise BreezeError(f"连不上 {self.base}：{exc}") from exc
        if not isinstance(data, list):
            raise BreezeError("音色库返回格式不对，期望是数组")
        return data

    async def synthesize(
        self,
        text: str,
        voice_id: str,
        instruction: str = "",
        cfg_scale: float = 1.0,
        seed: int = 42,
    ) -> bytes:
        """服务端流式吐 PCM，这里一次性收完再套 WAV 头。"""
        session = await self._get_session()
        form = aiohttp.FormData()
        form.add_field("text", text)
        form.add_field("voice_id", voice_id)
        form.add_field("cfg_scale", str(cfg_scale))
        form.add_field("seed", str(seed))
        if instruction:
            form.add_field("instruction", instruction)
        try:
            async with session.post(f"{self.base}/v1/audio/speech", data=form) as resp:
                if resp.status != 200:
                    body = (await resp.text())[:200]
                    raise BreezeError(f"合成失败（HTTP {resp.status}）：{body}")
                pcm = await resp.read()
                rate = int(resp.headers.get("X-Sample-Rate") or 24000)
        except aiohttp.ClientError as exc:
            raise BreezeError(f"连不上 {self.base}：{exc}") from exc
        if not pcm:
            raise BreezeError("服务端返回了空音频")
        return pcm_to_wav(pcm, rate)


class BreezeLocalPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig | None = None) -> None:
        super().__init__(context)
        self.config: Any = config or {}
        self._client: BreezeClient | None = None
        self._lock = asyncio.Lock()
        self._cache: AudioCache | None = None
        self._hits = 0
        self._misses = 0

        if context is not None and hasattr(context, "register_web_api"):
            context.register_web_api(
                f"/{PLUGIN_NAME}/voices", self.api_voices, ["GET"], "拉取 Breeze 音色库"
            )
            context.register_web_api(
                f"/{PLUGIN_NAME}/select", self.api_select, ["POST"], "设置默认音色"
            )
            context.register_web_api(
                f"/{PLUGIN_NAME}/cache/clear", self.api_clear_cache, ["POST"], "清空音频缓存"
            )

    # -- 配置 ---------------------------------------------------------------

    def _get(self, key: str, default: Any = None) -> Any:
        try:
            value = self.config.get(key, default)
        except AttributeError:
            value = default
        return default if value is None else value

    def _bool(self, key: str, default: bool) -> bool:
        value = self._get(key, default)
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on")
        return bool(value)

    def _num(self, key: str, default: float, low: float | None = None, high: float | None = None) -> float:
        try:
            value = float(self._get(key, default))
        except (TypeError, ValueError):
            value = default
        if low is not None:
            value = max(low, value)
        if high is not None:
            value = min(high, value)
        return value

    @property
    def base(self) -> str:
        return str(self._get("api_base", DEFAULT_BASE)).strip().rstrip("/") or DEFAULT_BASE

    @property
    def timeout(self) -> float:
        return float(self._get("timeout", 120))

    @property
    def default_voice(self) -> str:
        return str(self._get("voice_id", "")).strip()

    async def client(self) -> BreezeClient:
        async with self._lock:
            if self._client is None:
                self._client = BreezeClient(self.base, self.timeout)
            return self._client

    def cache(self) -> AudioCache:
        """缓存目录放在插件自己的 data 目录下。"""
        if self._cache is None:
            root = self._data_dir() / "cache"
            self._cache = AudioCache(
                root,
                expire_hours=self._num("cache_expire_hours", 30, 0, 8760),
                enabled=self._bool("cache_enabled", True),
            )
        return self._cache

    def _data_dir(self) -> Path:
        try:
            from astrbot.core.utils.astrbot_path import get_astrbot_data_path

            return Path(get_astrbot_data_path()) / "plugin_data" / PLUGIN_NAME
        except Exception:
            return Path(__file__).resolve().parent / "data"

    async def terminate(self) -> None:
        if self._client is not None:
            await self._client.close()
        self._client = None

    # -- 指令 ---------------------------------------------------------------

    @filter.command("tts")
    async def cmd_tts(self, event: AstrMessageEvent, text: str = ""):
        """把文字读出来。引用一条消息再发 /tts 也行。"""
        content = text.strip() or self._quoted_text(event)
        if not content:
            yield event.plain_result("要说点什么呢？发 /tts 后面跟文字，或者引用一条消息。")
            return

        try:
            wav = await self._speak(content)
        except BreezeError as exc:
            logger.warning("Breeze 合成失败：%s", exc)
            yield event.plain_result(f"语音合成失败：{exc}")
            return

        yield event.chain_result([Record.fromFileSystem(self._write_temp(wav))])

    @filter.command("tts_voice")
    async def cmd_voice(self, event: AstrMessageEvent, action: str = "list", arg: str = ""):
        """查看或切换音色。用法：/tts_voice list | show"""
        action = (action or "list").lower()

        if action in ("list", "ls"):
            try:
                client = await self.client()
                voices = await client.list_voices()
            except BreezeError as exc:
                yield event.plain_result(f"拉取音色库失败：{exc}")
                return
            if not voices:
                yield event.plain_result("服务端还没有音色，先去本机的语音库页面存几个吧。")
                return
            lines = [f"当前音色：{self.default_voice or '未设置'}", f"共 {len(voices)} 个："]
            for v in voices:
                vid = v.get("id") or "?"
                secs = v.get("seconds") or 0
                note = v.get("description") or (v.get("ref_text") or "")[:24]
                lines.append(f"· {vid}（{secs:.1f}s）{note}")
            lines.append("在插件页把某个音色设为默认即可切换。")
            yield event.plain_result("\n".join(lines))
            return

        if action in ("show", "info"):
            stats = self.cache().stats()
            yield event.plain_result(
                f"服务地址：{self.base}\n"
                f"默认音色：{self.default_voice or '未设置'}\n"
                f"缓存：{stats['files']} 个文件 / {stats['bytes'] / 1048576:.1f} MB\n"
                f"命中 {self._hits} 次，未命中 {self._misses} 次"
            )
            return

        yield event.plain_result("用法：/tts_voice list 或 /tts_voice show")

    @filter.command("tts_cache")
    async def cmd_cache(self, event: AstrMessageEvent, action: str = "stats"):
        """音频缓存管理。用法：/tts_cache stats | clear"""
        cache = self.cache()
        if (action or "stats").lower() == "clear":
            n = cache.clear()
            self._hits = self._misses = 0
            yield event.plain_result(f"已清掉 {n} 个缓存文件。")
            return
        stats = cache.stats()
        yield event.plain_result(
            f"缓存 {stats['files']} 个文件，共 {stats['bytes'] / 1048576:.1f} MB\n"
            f"本次运行命中 {self._hits} 次，未命中 {self._misses} 次\n"
            f"过期时间：{self._num('cache_expire_hours', 30)} 小时（0 表示永不过期）"
        )

    # -- 主动转语音 ---------------------------------------------------------

    @filter.on_decorating_result()
    async def maybe_voice(self, event: AstrMessageEvent):
        """按概率把 LLM 的文字回复改成语音。"""
        if not self._bool("auto_voice_enabled", False):
            return

        result = event.get_result()
        if result is None:
            return

        # 只处理 LLM 返回的消息
        if self._bool("only_llm_result", True) and not getattr(result, "is_llm_result", lambda: True)():
            return

        # 已经带语音了就不重复
        for comp in result.chain or []:
            if comp.__class__.__name__ == "Record":
                return

        text = clean_text(result.get_plain_text())
        if not text:
            return

        limit = int(self._num("max_text_length", 50, 0, 100000))
        if limit > 0 and len(text) > limit:
            return

        if random.random() > self._num("auto_voice_probability", 0.15, 0.0, 1.0):
            return

        try:
            instruction = await self._judge_emotion(text)
            wav = await self._speak(text, instruction)
        except BreezeError as exc:
            logger.warning("Breeze 主动转语音失败，保留原文字：%s", exc)
            return
        except Exception:
            logger.exception("Breeze 主动转语音出现意外错误")
            return

        path = self._write_temp(wav)
        record = Record.fromFileSystem(path)

        if self._bool("replace_text", False):
            # 拦截文字，只发语音
            result.chain = [record]
        else:
            result.chain = [record, *list(result.chain or [])]

    async def _judge_emotion(self, text: str) -> str:
        """让一个小模型判断该用什么语气说这句话，返回表演指令。"""
        if not self._bool("emotion_enabled", True):
            return ""

        provider_id = str(self._get("emotion_provider_id", "") or "").strip()
        try:
            provider = (
                self.context.get_provider_by_id(provider_id)
                if provider_id
                else self.context.get_using_provider()
            )
            if provider is None:
                return ""
            resp = await provider.text_chat(
                prompt=(
                    "根据下面这句话的情绪，用一句简短的中文描述该怎么念出来，"
                    "只输出描述本身，不要引号不要解释，20 字以内。\n\n"
                    f"{text}"
                ),
                system_prompt="你是一个语音表演指导。",
            )
            instruction = clean_text(getattr(resp, "completion_text", "") or "")
            if instruction:
                logger.debug("Breeze 情感指令：%s", instruction)
            return instruction[:60]
        except Exception as exc:
            logger.warning("情感判断失败，退回默认语气：%s", exc)
            return ""

    # -- LLM 工具 -----------------------------------------------------------

    @filter.llm_tool(name="breeze_speak")
    async def tool_speak(self, event: AstrMessageEvent, text: str, instruction: str = ""):
        """用 Breeze TTS 合成语音并发送。用户要求发语音、朗读、读出来时调用。

        Args:
            text(string): 要朗读的最终文本
            instruction(string): 可选，表演指令，描述语气情绪语速，例如"温柔地、放慢语速"
        """
        try:
            wav = await self._speak(text, instruction)
        except BreezeError as exc:
            logger.warning("Breeze 工具合成失败：%s", exc)
            yield f"语音合成失败：{exc}"
            return
        yield event.chain_result([Record.fromFileSystem(self._write_temp(wav))])

    # -- 插件页 API ---------------------------------------------------------

    async def api_voices(self):
        """给插件页用的音色列表，顺便把裸数组整理成带名字的结构。"""
        try:
            client = await self.client()
            raw = await client.list_voices()
        except BreezeError as exc:
            return await self._json({"error": str(exc)}, 502)

        voices = []
        for v in raw:
            vid = str(v.get("id") or "")
            if not vid:
                continue
            voices.append(
                {
                    "voice_id": vid,
                    "name": v.get("description") or vid,
                    "seconds": round(float(v.get("seconds") or 0), 2),
                    "ref_text": v.get("ref_text") or "",
                    "description": v.get("description") or "",
                    "metadata": v.get("metadata") or {},
                    "saved": bool(v.get("saved")),
                }
            )
        cache_stats = self.cache().stats()
        return await self._json(
            {
                "voices": voices,
                "total": len(voices),
                "selected_voice_id": self.default_voice,
                "api_base": self.base,
                "cache": {
                    "files": cache_stats["files"],
                    "mb": round(cache_stats["bytes"] / 1048576, 2),
                    "hits": self._hits,
                    "misses": self._misses,
                    "expire_hours": self._num("cache_expire_hours", 30),
                    "enabled": self._bool("cache_enabled", True),
                },
            }
        )

    async def api_select(self):
        payload = await self._read_json()
        voice_id = str((payload or {}).get("voice_id") or "").strip()
        if not voice_id:
            return await self._json({"error": "voice_id 不能为空"}, 400)

        try:
            client = await self.client()
            voices = await client.list_voices()
        except BreezeError as exc:
            return await self._json({"error": str(exc)}, 502)

        if voice_id not in {str(v.get("id")) for v in voices}:
            return await self._json({"error": f"不存在的音色：{voice_id}"}, 404)

        try:
            self.config["voice_id"] = voice_id
            self.config.save_config()
        except Exception as exc:  # 某些版本没有 save_config
            logger.warning("保存 voice_id 失败，仅本次生效：%s", exc)
        return await self._json({"voice_id": voice_id})

    async def api_clear_cache(self):
        n = self.cache().clear()
        self._hits = self._misses = 0
        return await self._json({"cleared": n})

    @staticmethod
    async def _json(payload, status: int = 200):
        from astrbot.api.web import json_response

        body = json_response(payload)
        if asyncio.iscoroutine(body):
            body = await body
        return body

    @staticmethod
    async def _read_json():
        from astrbot.api.web import request

        data = request.json()
        if asyncio.iscoroutine(data):
            data = await data
        return data

    # -- 内部 ---------------------------------------------------------------

    async def _speak(self, text: str, instruction: str = "") -> bytes:
        voice = self.default_voice
        if not voice:
            try:
                voices = await (await self.client()).list_voices()
            except BreezeError:
                voices = []
            if voices:
                voice = str(voices[0].get("id") or "")
        if not voice:
            raise BreezeError("没有可用的音色，请先在插件页选择或手动填写 voice_id")

        cfg = float(self._num("cfg_scale", 2.0, 1.0, 10.0))
        seed = int(self._num("seed", 42))

        cache = self.cache()
        key = cache.make_key(voice, text, instruction, cfg, seed)
        hit = cache.get(key)
        if hit is not None:
            self._hits += 1
            return hit
        self._misses += 1

        client = await self.client()
        wav = await client.synthesize(
            text=text,
            voice_id=voice,
            instruction=instruction,
            cfg_scale=cfg,
            seed=seed,
        )
        cache.put(key, wav)
        return wav

    def _write_temp(self, wav: bytes) -> str:
        import tempfile

        fd, path = tempfile.mkstemp(suffix=".wav", prefix="breeze_")
        with open(fd, "wb") as f:
            f.write(wav)
        return path

    @staticmethod
    def _quoted_text(event: AstrMessageEvent) -> str:
        for seg in getattr(event.message_obj, "message", []) or []:
            if getattr(seg, "type", "") == "Quote":
                text = str(getattr(seg, "text", "") or "").strip()
                if text:
                    return text
        return ""

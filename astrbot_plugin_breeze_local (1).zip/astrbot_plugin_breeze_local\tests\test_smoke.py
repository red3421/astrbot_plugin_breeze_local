"""离线冒烟测试：不依赖 AstrBot 实例，用打桩的方式验证真实逻辑。

跑法：
    python tests/test_smoke.py
需要本机 breeze-server 在 127.0.0.1:8080 上跑着。
"""

from __future__ import annotations

import asyncio
import io
import sys
import types
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# ---- 打桩 astrbot ---------------------------------------------------------
astrbot = types.ModuleType("astrbot")
api = types.ModuleType("astrbot.api")
api.logger = types.SimpleNamespace(warning=print, info=print, exception=print)

event_mod = types.ModuleType("astrbot.api.event")
message_mod = types.ModuleType("astrbot.api.message_components")
star_mod = types.ModuleType("astrbot.api.star")
config_mod = types.ModuleType("astrbot.core.config.astrbot_config")


class Star:
    def __init__(self, context):
        self.context = context


class Record:
    def __init__(self, path):
        self.path = path

    @classmethod
    def fromFileSystem(cls, path):
        return cls(path)


event_mod.AstrMessageEvent = object
event_mod.filter = types.SimpleNamespace(
    command=lambda *_a, **_k: (lambda f: f),
    llm_tool=lambda *_a, **_k: (lambda f: f),
    on_decorating_result=lambda *_a, **_k: (lambda f: f),
)
message_mod.Record = Record
star_mod.Context = object
star_mod.Star = Star
config_mod.AstrBotConfig = dict

utils_mod = types.ModuleType("astrbot.core.utils")
path_mod = types.ModuleType("astrbot.core.utils.astrbot_path")
path_mod.get_astrbot_data_path = lambda: str(ROOT / "data")

sys.modules.update(
    {
        "astrbot": astrbot,
        "astrbot.api": api,
        "astrbot.api.event": event_mod,
        "astrbot.api.message_components": message_mod,
        "astrbot.api.star": star_mod,
        "astrbot.core": types.ModuleType("astrbot.core"),
        "astrbot.core.config": types.ModuleType("astrbot.core.config"),
        "astrbot.core.config.astrbot_config": config_mod,
        "astrbot.core.utils": utils_mod,
        "astrbot.core.utils.astrbot_path": path_mod,
    }
)

import main  # noqa: E402


BASE = "http://127.0.0.1:8080"


def check_wav(data: bytes, expect_rate: int = 24000) -> float:
    with wave.open(io.BytesIO(data), "rb") as w:
        assert w.getnchannels() == 1, "应该是单声道"
        assert w.getsampwidth() == 2, "应该是 16 bit"
        assert w.getframerate() == expect_rate, f"采样率应为 {expect_rate}"
        return w.getnframes() / expect_rate


async def run() -> None:
    client = main.BreezeClient(BASE, 120)

    health = await client.health()
    print(f"[1] health ok: {health}")
    assert health.get("status") == "ok"
    rate = int(health.get("sample_rate", 24000))

    voices = await client.list_voices()
    print(f"[2] 音色库 {len(voices)} 个")
    for v in voices:
        print(f"    · {v.get('id')}  {v.get('seconds')}s  {v.get('ref_text', '')[:20]}")
    assert voices, "服务端音色库不该是空的"
    assert all("id" in v for v in voices), "每项都要有 id 字段"

    vid = str(voices[0]["id"])
    wav = await client.synthesize("你好，这是来自本地语音库的测试。", vid, cfg_scale=1.0)
    dur = check_wav(wav, rate)
    print(f"[3] 合成 {vid} ok: {len(wav)} 字节 / {dur:.2f} 秒")
    assert dur > 0.3, "音频太短了"

    # 带表演指令走的是 direction 模式
    wav2 = await client.synthesize("哈哈，本鲸鱼娘才不会承认呢。", vid, instruction="带点笑意，语气轻快", cfg_scale=2.0)
    dur2 = check_wav(wav2, rate)
    print(f"[4] 带指令合成 ok: {dur2:.2f} 秒")
    assert dur2 > 0.3

    await client.close()

    # ---- 插件层 --------------------------------------------------------
    plugin = main.BreezeLocalPlugin(context=None, config={"api_base": BASE, "voice_id": ""})

    class FakeResp:
        def __init__(self, payload):
            self._p = payload

        async def json(self):
            return self._p

    def fake_json_response(payload):
        # 真 AstrBot 里这个可能是协程，插件已经两种都处理了
        return FakeResp(payload)

    web = types.ModuleType("astrbot.api.web")
    web.json_response = fake_json_response
    web.request = types.SimpleNamespace(json=lambda: {})
    sys.modules["astrbot.api.web"] = web

    resp = await plugin.api_voices()
    payload = await resp.json()
    print(f"[5] 插件页音色接口 ok: total={payload['total']}")
    assert payload["total"] == len(voices)
    assert payload["voices"][0]["voice_id"] == vid
    assert "name" in payload["voices"][0]

    # 选一个不存在的音色应该报 404
    bad = await plugin.api_select()
    bad_payload = await bad.json()
    print(f"[6] 拒绝空 voice_id ok: {bad_payload}")
    assert "error" in bad_payload

    # 没配默认音色时，自动挑第一个
    wav3 = await plugin._speak("自动选音色测试。")
    print(f"[7] 自动选音色 ok: {check_wav(wav3, rate):.2f} 秒")

    # ---- 缓存 ----------------------------------------------------------
    plugin.cache().clear()  # 先清干净，从零开始数
    plugin._hits = plugin._misses = 0

    wav3 = await plugin._speak("自动选音色测试。")  # 第一次：未命中
    assert plugin._misses == 1 and plugin._hits == 0

    wav4 = await plugin._speak("自动选音色测试。")  # 同参数：命中
    wav5 = await plugin._speak("自动选音色测试。", "换个语气")  # 不同指令：未命中

    print(f"[8] 缓存 hits={plugin._hits} misses={plugin._misses}")
    assert plugin._hits == 1, "同参数第二次应命中缓存"
    assert plugin._misses == 2, "不同指令应算未命中"
    assert wav4 == wav3, "命中缓存内容应完全一致"
    stats = plugin.cache().stats()
    print(f"    缓存文件 {stats['files']} 个 / {stats['bytes'] / 1048576:.2f} MB")
    assert stats["files"] == 2, "两次未命中应产生两个缓存文件"

    # ---- 文本清洗 -------------------------------------------------------
    dirty = "**你好** 呀～\n```python\nprint(1)\n```\n[链接](https://x.com) 看看 `代码`"
    cleaned = main.clean_text(dirty)
    print(f"[9] 文本清洗：{cleaned!r}")
    assert "**" not in cleaned and "```" not in cleaned
    assert "https://" not in cleaned and "你好" in cleaned

    # ---- 主动转语音：概率 0 时不该动 --------------------------------
    class FakeResult:
        def __init__(self, text, llm=True):
            self.chain = [types.SimpleNamespace(text=text)]
            self._llm = llm

        def is_llm_result(self):
            return self._llm

        def get_plain_text(self):
            return "".join(getattr(c, "text", "") for c in self.chain)

    class FakeEvent:
        def __init__(self, result):
            self._result = result

        def get_result(self):
            return self._result

    plugin.config.update(
        {"auto_voice_enabled": True, "auto_voice_probability": 0.0, "emotion_enabled": False}
    )
    res = FakeResult("这条不该被转成语音。")
    await plugin.maybe_voice(FakeEvent(res))
    print("[10] 概率 0 时不转换 ok")
    assert len(res.chain) == 1 and res.chain[0].__class__.__name__ != "Record"

    # 超长文本也不该转
    plugin.config.update({"auto_voice_probability": 1.0, "max_text_length": 5})
    res = FakeResult("这条很长很长很长很长，超过限制了。")
    await plugin.maybe_voice(FakeEvent(res))
    print("[11] 超长文本不转换 ok")
    assert res.chain[0].__class__.__name__ != "Record"

    # 概率 1 + 拦截文字 → 只剩语音
    plugin.config.update(
        {"max_text_length": 200, "replace_text": True, "auto_voice_probability": 1.0}
    )
    res = FakeResult("换成语音吧。")
    await plugin.maybe_voice(FakeEvent(res))
    names = [c.__class__.__name__ for c in res.chain]
    print(f"[12] 拦截文字只发语音 ok: {names}")
    assert names == ["Record"], "打开拦截后应该只剩语音"

    # 不拦截 → 语音+文字都在
    plugin.config.update({"replace_text": False})
    res = FakeResult("语音和文字都要。")
    await plugin.maybe_voice(FakeEvent(res))
    names = [c.__class__.__name__ for c in res.chain]
    print(f"[13] 不拦截时语音+文字 ok: {names}")
    assert names == ["Record", "SimpleNamespace"]

    # 非 LLM 结果应被跳过
    plugin.config.update({"only_llm_result": True})
    res = FakeResult("指令回执不该转。", llm=False)
    await plugin.maybe_voice(FakeEvent(res))
    print("[14] 只处理 LLM 结果 ok")
    assert res.chain[0].__class__.__name__ != "Record"

    await plugin.terminate()
    print("\n全部通过 ✅")


if __name__ == "__main__":
    asyncio.run(run())

"""AstrBot 插件：把本机 Breeze-TTS-2.cpp 服务接入 AstrBot。

只做三件事：
1. 拉取服务端的音色库（GET /v1/voices）
2. 用选中的音色合成语音（POST /v1/audio/speech）
3. 提供一个插件页让用户挑音色

作者自用，不堆功能。
"""

from __future__ import annotations

import asyncio
import io
import json
import struct
import wave
from typing import Any

import aiohttp

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import Record
from astrbot.api.star import Context, Star
from astrbot.core.config.astrbot_config import AstrBotConfig

PLUGIN_NAME = "astrbot_plugin_breeze_local"

DEFAULT_BASE = "http://127.0.0.1:8080"


class BreezeError(Exception):
    """服务端返回错误或连接失败。"""


def pcm_to_wav(pcm: bytes, sample_rate: int = 24000) -> bytes:
    """服务端返回的是裸 16-bit 单声道 PCM，套个 WAV 头才能播。"""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm)
    return buf.getvalue()


class BreezeClient:
    """跟本机 breeze-server 说话的最小封装。"""

    def __init__(self, base: str, timeout: float) -> None:
        self.base = base.rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=self.timeout)
        return self._session

    async def close(self) -> None:
        if self._session is not None and not self._session.closed:
            await self._session.close()
        self._session = None

    async def health(self) -> dict[str, Any]:
        session = await self._get_session()
        try:
            async with session.get(f"{self.base}/health") as resp:
                if resp.status != 200:
                    raise BreezeError(f"服务不可达（HTTP {resp.status}）")
                return await resp.json()
        except aiohttp.ClientError as exc:
            raise BreezeError(f"连不上 {self.base}：{exc}") from exc

    async def list_voices(self) -> list[dict[str, Any]]:
        """服务端返回的是裸数组，每项形如 {id, seconds, ref_text, description, metadata, ...}。"""
        session = await self._get_session()
        try:
            async with session.get(f"{self.base}/v1/voices") as resp:
                if resp.status != 200:
                    raise BreezeError(f"拉取音色库失败（HTTP {resp.status}）")
                data = await resp.json(content_type=None)
        except aiohttp.ClientError as exc:
            raise BreezeError(f"连不上 {self.base}：{exc}") from exc
        if not isinstance(data, list):
            raise BreezeError("音色库返回格式不对，期望是数组")
        return data

    async def synthesize(
        self,
        text: str,
        voice_id: str,
        instruction: str = "",
        cfg_scale: float = 1.0,
        seed: int = 42,
    ) -> bytes:
        """服务端流式吐 PCM，这里一次性收完再套 WAV 头。"""
        session = await self._get_session()
        form = aiohttp.FormData()
        form.add_field("text", text)
        form.add_field("voice_id", voice_id)
        form.add_field("cfg_scale", str(cfg_scale))
        form.add_field("seed", str(seed))
        if instruction:
            form.add_field("instruction", instruction)
        try:
            async with session.post(f"{self.base}/v1/audio/speech", data=form) as resp:
                if resp.status != 200:
                    body = (await resp.text())[:200]
                    raise BreezeError(f"合成失败（HTTP {resp.status}）：{body}")
                pcm = await resp.read()
                rate = int(resp.headers.get("X-Sample-Rate") or 24000)
        except aiohttp.ClientError as exc:
            raise BreezeError(f"连不上 {self.base}：{exc}") from exc
        if not pcm:
            raise BreezeError("服务端返回了空音频")
        return pcm_to_wav(pcm, rate)


class BreezeLocalPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig | None = None) -> None:
        super().__init__(context)
        self.config: Any = config or {}
        self._client: BreezeClient | None = None
        self._lock = asyncio.Lock()

        if hasattr(context, "register_web_api"):
            context.register_web_api(
                f"/{PLUGIN_NAME}/voices", self.api_voices, ["GET"], "拉取 Breeze 音色库"
            )
            context.register_web_api(
                f"/{PLUGIN_NAME}/select", self.api_select, ["POST"], "设置默认音色"
            )

    # -- 配置 ---------------------------------------------------------------

    def _get(self, key: str, default: Any = None) -> Any:
        try:
            value = self.config.get(key, default)
        except AttributeError:
            value = default
        return default if value is None else value

    @property
    def base(self) -> str:
        return str(self._get("api_base", DEFAULT_BASE)).strip().rstrip("/") or DEFAULT_BASE

    @property
    def timeout(self) -> float:
        return float(self._get("timeout", 120))

    @property
    def default_voice(self) -> str:
        return str(self._get("voice_id", "")).strip()

    async def client(self) -> BreezeClient:
        async with self._lock:
            if self._client is None:
                self._client = BreezeClient(self.base, self.timeout)
            return self._client

    async def terminate(self) -> None:
        if self._client is not None:
            await self._client.close()
        self._client = None

    # -- 指令 ---------------------------------------------------------------

    @filter.command("tts")
    async def cmd_tts(self, event: AstrMessageEvent, text: str = ""):
        """把文字读出来。引用一条消息再发 /tts 也行。"""
        content = text.strip() or self._quoted_text(event)
        if not content:
            yield event.plain_result("要说点什么呢？发 /tts 后面跟文字，或者引用一条消息。")
            return

        try:
            wav = await self._speak(content)
        except BreezeError as exc:
            logger.warning("Breeze 合成失败：%s", exc)
            yield event.plain_result(f"语音合成失败：{exc}")
            return

        path = self._write_temp(wav)
        yield event.chain_result([Record.fromFileSystem(path)])

    @filter.command("tts_voice")
    async def cmd_voice(self, event: AstrMessageEvent, action: str = "list", arg: str = ""):
        """查看或切换音色。用法：/tts_voice list | show"""
        action = (action or "list").lower()

        if action in ("list", "ls"):
            try:
                client = await self.client()
                voices = await client.list_voices()
            except BreezeError as exc:
                yield event.plain_result(f"拉取音色库失败：{exc}")
                return
            if not voices:
                yield event.plain_result("服务端还没有音色，先去本机的语音库页面存几个吧。")
                return
            lines = [f"当前音色：{self.default_voice or '未设置'}", f"共 {len(voices)} 个："]
            for v in voices:
                vid = v.get("id") or "?"
                secs = v.get("seconds") or 0
                note = v.get("description") or (v.get("ref_text") or "")[:24]
                lines.append(f"· {vid}（{secs:.1f}s）{note}")
            lines.append("在插件页把某个音色设为默认即可切换。")
            yield event.plain_result("\n".join(lines))
            return

        if action in ("show", "info"):
            yield event.plain_result(
                f"服务地址：{self.base}\n默认音色：{self.default_voice or '未设置'}"
            )
            return

        yield event.plain_result("用法：/tts_voice list 或 /tts_voice show")

    # -- LLM 工具 -----------------------------------------------------------

    @filter.llm_tool(name="breeze_speak")
    async def tool_speak(self, event: AstrMessageEvent, text: str, instruction: str = ""):
        """用 Breeze TTS 合成语音并发送。用户要求发语音、朗读、读出来时调用。

        Args:
            text(string): 要朗读的最终文本
            instruction(string): 可选，表演指令，描述语气情绪语速，例如"温柔地、放慢语速"
        """
        try:
            wav = await self._speak(text, instruction)
        except BreezeError as exc:
            logger.warning("Breeze 工具合成失败：%s", exc)
            yield f"语音合成失败：{exc}"
            return
        yield event.chain_result([Record.fromFileSystem(self._write_temp(wav))])

    # -- 插件页 API ---------------------------------------------------------

    async def api_voices(self):
        """给插件页用的音色列表，顺便把裸数组整理成带名字的结构。"""
        try:
            client = await self.client()
            raw = await client.list_voices()
        except BreezeError as exc:
            return await self._json({"error": str(exc)}, 502)

        voices = []
        for v in raw:
            vid = str(v.get("id") or "")
            if not vid:
                continue
            voices.append(
                {
                    "voice_id": vid,
                    "name": v.get("description") or vid,
                    "seconds": round(float(v.get("seconds") or 0), 2),
                    "ref_text": v.get("ref_text") or "",
                    "description": v.get("description") or "",
                    "metadata": v.get("metadata") or {},
                    "saved": bool(v.get("saved")),
                }
            )
        return await self._json(
            {
                "voices": voices,
                "total": len(voices),
                "selected_voice_id": self.default_voice,
                "api_base": self.base,
            }
        )

    async def api_select(self):
        payload = await self._read_json()
        voice_id = str((payload or {}).get("voice_id") or "").strip()
        if not voice_id:
            return await self._json({"error": "voice_id 不能为空"}, 400)

        try:
            client = await self.client()
            voices = await client.list_voices()
        except BreezeError as exc:
            return await self._json({"error": str(exc)}, 502)

        if voice_id not in {str(v.get("id")) for v in voices}:
            return await self._json({"error": f"不存在的音色：{voice_id}"}, 404)

        try:
            self.config["voice_id"] = voice_id
            self.config.save_config()
        except Exception as exc:  # 某些版本没有 save_config
            logger.warning("保存 voice_id 失败，仅本次生效：%s", exc)
        return await self._json({"voice_id": voice_id})

    @staticmethod
    async def _json(payload, status: int = 200):
        from astrbot.api.web import json_response

        body = json_response(payload)
        if asyncio.iscoroutine(body):
            body = await body
        return body

    @staticmethod
    async def _read_json():
        from astrbot.api.web import request

        data = request.json()
        if asyncio.iscoroutine(data):
            data = await data
        return data

    # -- 内部 ---------------------------------------------------------------

    async def _speak(self, text: str, instruction: str = "") -> bytes:
        voice = self.default_voice
        if not voice:
            try:
                voices = await (await self.client()).list_voices()
            except BreezeError:
                voices = []
            if voices:
                voice = str(voices[0].get("id") or "")
        if not voice:
            raise BreezeError("没有可用的音色，请先在插件页选择或手动填写 voice_id")

        client = await self.client()
        return await client.synthesize(
            text=text,
            voice_id=voice,
            instruction=instruction,
            cfg_scale=float(self._get("cfg_scale", 2.0)),
            seed=int(self._get("seed", 42)),
        )

    def _write_temp(self, wav: bytes) -> str:
        import tempfile
        from pathlib import Path

        fd, path = tempfile.mkstemp(suffix=".wav", prefix="breeze_")
        with open(fd, "wb") as f:
            f.write(wav)
        return path

    @staticmethod
    def _quoted_text(event: AstrMessageEvent) -> str:
        for seg in getattr(event.message_obj, "message", []) or []:
            if getattr(seg, "type", "") == "Quote":
                text = str(getattr(seg, "text", "") or "").strip()
                if text:
                    return text
        return ""

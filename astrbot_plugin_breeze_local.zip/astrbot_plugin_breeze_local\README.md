# Breeze 本地语音（AstrBot 插件）

把本机跑的 [Breeze-TTS-2.cpp](https://github.com/HoppouAI/Breeze-TTS-2.cpp) 服务接进 AstrBot。
不自带模型，纯客户端：**拉服务端的音色库，用你存好的声音说话**。

## 它能干什么

- `/tts <文字>` — 读出来；引用一条消息再发 `/tts` 也能读那条
- `/tts_voice list` — 列出服务端音色库
- `/tts_voice show` — 看当前用的是哪个
- **LLM 工具 `breeze_speak`** — 模型觉得该发语音时自己调，可以带表演指令
- **插件页「语音库」** — 拉取音色列表，点一下设为默认

## 安装

1. 把整个 `astrbot_plugin_breeze_local` 文件夹丢进：

   ```
   AstrBot/data/plugins/astrbot_plugin_breeze_local/
   ```

2. AstrBot WebUI → 插件页 → 重载插件
3. 打开插件配置，填 **服务地址**

## 配置

| 配置项 | 默认值 | 说明 |
|---|---|---|
| `api_base` | `http://127.0.0.1:8080` | breeze-server 的地址。不同机器时填局域网 IP，比如 `http://192.168.5.7:8080` |
| `voice_id` | 空 | 默认音色 id。留空自动用音色库第一个 |
| `cfg_scale` | `2.0` | 表现力强度。`1.0` 原样朗读，2~3 语气更足，超 3 刺耳 |
| `seed` | `42` | 随机种子，换个数字就是换个说法 |
| `timeout` | `120` | 请求超时秒数 |

## 服务端要求

AstrBot 和 TTS **不在同一台机器**时，服务端必须监听所有网卡：

```powershell
breeze-server.exe "模型.gguf" --host 0.0.0.0 --port 8080 --webui
```

别忘了放行防火墙 8080 端口。

## 音色从哪来

音色是你在服务端存的，不是插件带的。两种办法：

**用 WebUI（推荐）** — 打开 `http://<服务端IP>:8080/`，切到「语音库」页签，上传一段干净录音 + 一字不差的文字稿，存一个名字。

**用命令行**

```powershell
breeze-cli.exe 模型.gguf --ref-audio 参考.wav --ref-text "参考音频的准确文字" --save-voice laotai
```

存完插件页点「刷新」就能看到。

> 参考音频 5~15 秒最合适，要干净、无背景音乐。转写必须和音频**一字不差**，错一个字克隆质量就崩。

## 指令示例

```
/tts 今天辛苦啦，早点休息。
/tts_voice list
```

引用别人的消息然后发 `/tts`，会读那条消息。

## 故障排查

| 现象 | 处理 |
|---|---|
| 拉取音色库失败 → 连不上 | 服务端没开，或者 `api_base` 填错，或者服务端没加 `--host 0.0.0.0` |
| 音色库是空的 | 服务端还没存音色，去 WebUI 语音库存一个 |
| 合成失败 HTTP 409 | 服务端一次只能跑一个请求，等上一条出完 |
| 发出去是杂音 | 一般是音频头问题，本插件已把裸 PCM 包成 WAV，若仍异常请反馈 |
| 模型不调用语音工具 | 在人格提示词里写明「需要语音时调用 `breeze_speak`」 |

## 测试

```bash
python tests/test_smoke.py
```

需要本机 breeze-server 在 8080 上跑着。7 项检查：健康检查、拉音色、普通合成、带指令合成、插件页接口、参数校验、自动选音色。

## 许可

插件代码随你处置。Breeze TTS 2 的**模型权重是 BreezeBlue 研究与非商用许可**，自托管产出的音频不能直接商用。

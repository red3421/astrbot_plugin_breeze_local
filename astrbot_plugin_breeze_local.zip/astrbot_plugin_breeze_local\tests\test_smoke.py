"""离线冒烟测试：不依赖 AstrBot 实例，用打桩的方式验证真实逻辑。

跑法：
    python tests/test_smoke.py
需要本机 breeze-server 在 127.0.0.1:8080 上跑着。
"""

from __future__ import annotations

import asyncio
import io
import sys
import types
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# ---- 打桩 astrbot ---------------------------------------------------------
astrbot = types.ModuleType("astrbot")
api = types.ModuleType("astrbot.api")
api.logger = types.SimpleNamespace(warning=print, info=print, exception=print)

event_mod = types.ModuleType("astrbot.api.event")
message_mod = types.ModuleType("astrbot.api.message_components")
star_mod = types.ModuleType("astrbot.api.star")
config_mod = types.ModuleType("astrbot.core.config.astrbot_config")


class Star:
    def __init__(self, context):
        self.context = context


class Record:
    def __init__(self, path):
        self.path = path

    @classmethod
    def fromFileSystem(cls, path):
        return cls(path)


event_mod.AstrMessageEvent = object
event_mod.filter = types.SimpleNamespace(
    command=lambda *_a, **_k: (lambda f: f),
    llm_tool=lambda *_a, **_k: (lambda f: f),
)
message_mod.Record = Record
star_mod.Context = object
star_mod.Star = Star
config_mod.AstrBotConfig = dict

sys.modules.update(
    {
        "astrbot": astrbot,
        "astrbot.api": api,
        "astrbot.api.event": event_mod,
        "astrbot.api.message_components": message_mod,
        "astrbot.api.star": star_mod,
        "astrbot.core": types.ModuleType("astrbot.core"),
        "astrbot.core.config": types.ModuleType("astrbot.core.config"),
        "astrbot.core.config.astrbot_config": config_mod,
    }
)

import main  # noqa: E402


BASE = "http://127.0.0.1:8080"


def check_wav(data: bytes, expect_rate: int = 24000) -> float:
    with wave.open(io.BytesIO(data), "rb") as w:
        assert w.getnchannels() == 1, "应该是单声道"
        assert w.getsampwidth() == 2, "应该是 16 bit"
        assert w.getframerate() == expect_rate, f"采样率应为 {expect_rate}"
        return w.getnframes() / expect_rate


async def run() -> None:
    client = main.BreezeClient(BASE, 120)

    health = await client.health()
    print(f"[1] health ok: {health}")
    assert health.get("status") == "ok"
    rate = int(health.get("sample_rate", 24000))

    voices = await client.list_voices()
    print(f"[2] 音色库 {len(voices)} 个")
    for v in voices:
        print(f"    · {v.get('id')}  {v.get('seconds')}s  {v.get('ref_text', '')[:20]}")
    assert voices, "服务端音色库不该是空的"
    assert all("id" in v for v in voices), "每项都要有 id 字段"

    vid = str(voices[0]["id"])
    wav = await client.synthesize("你好，这是来自本地语音库的测试。", vid, cfg_scale=1.0)
    dur = check_wav(wav, rate)
    print(f"[3] 合成 {vid} ok: {len(wav)} 字节 / {dur:.2f} 秒")
    assert dur > 0.3, "音频太短了"

    # 带表演指令走的是 direction 模式
    wav2 = await client.synthesize("哈哈，本鲸鱼娘才不会承认呢。", vid, instruction="带点笑意，语气轻快", cfg_scale=2.0)
    dur2 = check_wav(wav2, rate)
    print(f"[4] 带指令合成 ok: {dur2:.2f} 秒")
    assert dur2 > 0.3

    await client.close()

    # ---- 插件层 --------------------------------------------------------
    plugin = main.BreezeLocalPlugin(context=None, config={"api_base": BASE, "voice_id": ""})

    class FakeResp:
        def __init__(self, payload):
            self._p = payload

        async def json(self):
            return self._p

    def fake_json_response(payload):
        # 真 AstrBot 里这个可能是协程，插件已经两种都处理了
        return FakeResp(payload)

    web = types.ModuleType("astrbot.api.web")
    web.json_response = fake_json_response
    web.request = types.SimpleNamespace(json=lambda: {})
    sys.modules["astrbot.api.web"] = web

    resp = await plugin.api_voices()
    payload = await resp.json()
    print(f"[5] 插件页音色接口 ok: total={payload['total']}")
    assert payload["total"] == len(voices)
    assert payload["voices"][0]["voice_id"] == vid
    assert "name" in payload["voices"][0]

    # 选一个不存在的音色应该报 404
    bad = await plugin.api_select()
    bad_payload = await bad.json()
    print(f"[6] 拒绝空 voice_id ok: {bad_payload}")
    assert "error" in bad_payload

    # 没配默认音色时，自动挑第一个
    wav3 = await plugin._speak("自动选音色测试。")
    print(f"[7] 自动选音色 ok: {check_wav(wav3, rate):.2f} 秒")

    await plugin.terminate()
    print("\n全部通过 ✅")


if __name__ == "__main__":
    asyncio.run(run())
